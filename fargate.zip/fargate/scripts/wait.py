# lambda_function.py

import boto3
import json

ecs_client = boto3.client('ecs', region_name='us-east-1')

def is_service_running(cluster_name, service_name):
    try:
        response = ecs_client.describe_services(
            cluster=cluster_name,
            services=[service_name]
        )
        for service in response['services']:
            if service['runningCount'] > 0:
                return True
        return False
    except Exception as e:
        print(f"Error checking service status: {str(e)}")
        return False

def lambda_handler(event, context):
    cluster_name = "yourClusterName"
    service_name = "yourServiceName"

    if is_service_running(cluster_name, service_name):
        # Forward the request to the Fargate service (handled by CloudFront)
        return event['Records'][0]['cf']['request']
    else:
        # Return the static waiting page
        return {
            'status': '200',
            'statusDescription': 'OK',
            'headers': {'content-type': [{'key': 'Content-Type', 'value': 'text/html'}]},
            'body': '<html><body><h1>Service is starting, please wait...</h1></body></html>'
        }
