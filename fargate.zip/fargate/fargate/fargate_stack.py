from aws_cdk import aws_ecs as ecs
from aws_cdk import aws_ec2 as ec2
from aws_cdk import aws_dynamodb as dynamodb
from aws_cdk import Stack, CfnOutput, Duration, aws_lambda, aws_cloudfront, aws_s3_assets
from aws_cdk import aws_elasticloadbalancingv2 as elbv2
from constructs import Construct

class FargateStack(Stack):

    def __init__(self, scope: Construct, id: str, **kwargs) -> None:
        super().__init__(scope, id, **kwargs)

        # Create a VPC
        vpc = ec2.Vpc(self, "Vpc", max_azs=2)
        
        data_folder_asset = aws_s3_assets.Asset(self, "DataFolderAsset", path="../data")

        # Create an ECS cluster
        cluster = ecs.Cluster(self, "Cluster", vpc=vpc)
        
        data_volume = ecs.Volume(
            name="DataVolume",
            docker_volume_configuration=ecs.DockerVolumeConfiguration(
                driver="local",
                scope=ecs.Scope.TASK,
                autoprovision=True,
                labels={"com.grafana.data": "true"},
                driver_opts={
                    "type": "none",
                    "device": data_folder_asset.s3_object_url,
                    "o": "bind",
                },
            ),
            configured_at_launch=True
        )
        CfnOutput(self, "S3ObjectURL", value=data_folder_asset.s3_object_url)
        
        

        # Define the task definition with Grafana container
        task_definition = ecs.FargateTaskDefinition(self, "TaskDef")
        task_definition.node.add_dependency(data_folder_asset)
        container = task_definition.add_container("GrafanaContainer",
                              image=ecs.ContainerImage.from_registry(
                                  "grafana/grafana"),
                              memory_limit_mib=512,
                              cpu=256,
                              environment={})
        
        container.add_mount_points(
            ecs.MountPoint(
                container_path="/var/lib/grafana",  
                source_volume=data_volume.name,
                read_only=False,  
            )
        )

        # Create a Fargate Service
        fargate_service = ecs.FargateService(self, "Service",
                                             cluster=cluster,
                                             task_definition=task_definition,
                                             desired_count=1)

        # DynamoDB table
        table = dynamodb.Table(
            self, "Table",
            partition_key=dynamodb.Attribute(
                name="id",
                type=dynamodb.AttributeType.STRING
            )
        )
        
        # Create a load balancer
        lb = elbv2.ApplicationLoadBalancer(
            self, "LB",
            vpc=vpc,
            internet_facing=True
        )

        # Add a listener
        listener = lb.add_listener("PublicListener", port=80, open=True)
        
        container.add_port_mappings(
            ecs.PortMapping(container_port=3000, host_port=3000)
            )

        # Add target group
        health_check = elbv2.HealthCheck(interval=Duration.seconds(60), path="/")
        listener.add_targets("ECS",
                             port=3000,
                             protocol=elbv2.ApplicationProtocol.HTTP,
                             targets=[fargate_service],
                             health_check=health_check)
        
    

        # Output the URL of the Grafana service
        CfnOutput(self, "GrafanaURL",
                       value=lb.load_balancer_dns_name)
