$(document).ready(function() {
    $('#ladderTable').DataTable({
        "paging": false, // Disable paging (limit option)
        "searching": false // Disable search
    });
});